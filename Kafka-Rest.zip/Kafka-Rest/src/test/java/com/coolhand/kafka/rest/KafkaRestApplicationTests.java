package com.coolhand.kafka.rest;

//@SpringBootTest
class KafkaRestApplicationTests {

//	@Test
//	void contextLoads() {
//	}

}
