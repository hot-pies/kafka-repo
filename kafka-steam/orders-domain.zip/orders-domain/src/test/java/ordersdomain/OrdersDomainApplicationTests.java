package ordersdomain;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrdersDomainApplicationTests {

	@Test
	void contextLoads() {
	}

}
