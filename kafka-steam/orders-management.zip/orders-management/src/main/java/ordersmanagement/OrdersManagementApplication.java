package ordersmanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OrdersManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(OrdersManagementApplication.class, args);
	}

}
