package ordersmanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrdersManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
